// services/deliveryShelving.service.ts
import { Types } from "mongoose";
import Shelf, { type ShelfModel } from "../models/Shelf.model";
import Order from "../models/order.model";
import OrderPackage from "../models/OrderPackage.model";
import ApiError from "../utils/ApiError";
import { toObjectIdOrThrow, toIdString } from "@/utils/validations/mongose";

// Pick slot for a deliverer: prefer a slot “owned” by deliverer, else first suitable
function pickSlotIdForDeliverer(opts: { shelf: any; delivererId: Types.ObjectId | string }): string {
  const delivererSlot = (opts.shelf.slots || []).find(
    (s: any) => String(s.delivererId || "") === String(opts.delivererId)
  );
  if (delivererSlot) return String(delivererSlot.slotId);

  const available = (opts.shelf.slots || []).find((s: any) => {
    const canHoldPackages = s.allowedOccupant === "any" || s.allowedOccupant === "package";
    if (!canHoldPackages) return false;
    if (typeof s.maxPackages === "number" && s.maxPackages > 0) {
      if ((s.currentPackages || 0) >= s.maxPackages) return false;
    }
    return true;
  });

  if (!available) throw new ApiError(409, "No suitable delivery slot available on shelf");
  return String(available.slotId);
}

// Stage a single order’s package to its deliverer’s lane
export async function stageOrderToDelivererLane(args: { orderId: string; packageWeightKg?: number }) {
  const { orderId, packageWeightKg = 0 } = args;

  const order = await Order.findById(orderId).lean();
  if (!order) throw new ApiError(404, "Order not found");
  if (!order.LogisticsCenterId) throw new ApiError(400, "Order missing LogisticsCenterId");
  if (!order.assignedDelivererId) throw new ApiError(400, "Order not assigned to a deliverer");

  const lcId = toIdString(order.LogisticsCenterId)!; // string for queries is fine
  const delivererId = toObjectIdOrThrow(order.assignedDelivererId, "assignedDelivererId");

  const shelf = await Shelf.findOne({
    logisticCenterId: lcId,
    isDeliveryShelf: true,
    assignedDelivererId: delivererId,
  }).lean();

  if (!shelf) {
    throw new ApiError(404, "No delivery shelf assigned to this deliverer in this center");
  }

  const slotId = pickSlotIdForDeliverer({ shelf, delivererId });

  // idempotent package retrieval/creation
  let pkg = await OrderPackage.findOne({
    orderId: order._id,
    logisticCenterId: order.LogisticsCenterId,
    state: { $in: ["created", "staged"] },
  });

  if (!pkg) {
    pkg = await OrderPackage.create({
      orderId: order._id,
      logisticCenterId: order.LogisticsCenterId,
      delivererId,
      estWeightKg: packageWeightKg,
      state: "created",
    });
  }

  // mark staged on package
  if (typeof (pkg as any).markStaged === "function") {
    (pkg as any).markStaged(String(shelf.shelfId), String(slotId));
  } else {
    pkg.set({
      state: "staged",
      shelfId: String(shelf.shelfId),
      slotId: String(slotId),
      stagedAt: new Date(),
    } as any);
  }
  await pkg.save();

  // update shelf aggregates
  await (Shelf as unknown as ShelfModel).stagePackage({
    shelfId: String(shelf.shelfId),
    logisticCenterId: lcId,
    slotId: String(slotId),
    packageId: pkg._id,
    packageWeightKg,
    delivererId,
  });

  return {
    package: pkg.toObject(),
    stagedAt: { shelfId: shelf.shelfId, slotId },
  };
}

// Unstage
export async function unstageOrderPackage(args: { orderPackageId: string; packageWeightKg?: number }) {
  const { orderPackageId, packageWeightKg = 0 } = args;
  const pkg = await OrderPackage.findById(orderPackageId);
  if (!pkg) throw new ApiError(404, "OrderPackage not found");
  if (pkg.state !== "staged") throw new ApiError(409, `Package not staged (state=${pkg.state})`);
  if (!pkg.shelfId || !pkg.slotId) throw new ApiError(400, "Package missing shelf/slot info");

  await (Shelf as unknown as ShelfModel).unstagePackage({
    shelfId: String(pkg.shelfId),
    logisticCenterId: toIdString(pkg.logisticCenterId)!,
    slotId: String(pkg.slotId),
    packageId: pkg._id,
    packageWeightKg,
  });

  if (typeof (pkg as any).markCreated === "function") {
    (pkg as any).markCreated();
  } else {
    pkg.set({ state: "created", shelfId: null, slotId: null, stagedAt: null } as any);
  }
  await pkg.save();

  return { ok: true };
}

// Move staged package (same or different shelf)
export async function moveStagedOrderPackage(args: {
  orderPackageId: string;
  toDelivererId: string;
  toShelfId?: string;
  toSlotId?: string;
  packageWeightKg?: number;
}) {
  const { orderPackageId, toDelivererId, toShelfId, toSlotId, packageWeightKg = 0 } = args;

  const pkg = await OrderPackage.findById(orderPackageId);
  if (!pkg) throw new ApiError(404, "OrderPackage not found");
  if (pkg.state !== "staged") throw new ApiError(409, `Package not staged (state=${pkg.state})`);
  if (!pkg.shelfId || !pkg.slotId) throw new ApiError(400, "Package missing current shelf/slot");

  const lcId = toIdString(pkg.logisticCenterId)!;
  const toDelOid = toObjectIdOrThrow(toDelivererId, "toDelivererId");

  const destShelf = toShelfId
    ? await Shelf.findOne({ logisticCenterId: lcId, shelfId: toShelfId, isDeliveryShelf: true }).lean()
    : await Shelf.findOne({
        logisticCenterId: lcId,
        isDeliveryShelf: true,
        assignedDelivererId: toDelOid,
      }).lean();

  if (!destShelf) throw new ApiError(404, "Destination delivery shelf not found");
  const destSlotId = toSlotId || pickSlotIdForDeliverer({ shelf: destShelf, delivererId: toDelOid });

  const sameShelf = String(destShelf.shelfId) === String(pkg.shelfId);

  if (sameShelf && String(destSlotId) === String(pkg.slotId)) {
    return { ok: true, note: "Already in target slot" };
  }

  if (sameShelf) {
    await (Shelf as unknown as ShelfModel).moveStagedPackage({
      shelfId: String(pkg.shelfId),
      logisticCenterId: lcId,
      fromSlotId: String(pkg.slotId),
      toSlotId: String(destSlotId),
      packageId: pkg._id,
      packageWeightKg,
      toDelivererId: toDelOid,
    });
  } else {
    await (Shelf as unknown as ShelfModel).unstagePackage({
      shelfId: String(pkg.shelfId),
      logisticCenterId: lcId,
      slotId: String(pkg.slotId),
      packageId: pkg._id,
      packageWeightKg,
    });

    await (Shelf as unknown as ShelfModel).stagePackage({
      shelfId: String(destShelf.shelfId),
      logisticCenterId: lcId,
      slotId: String(destSlotId),
      packageId: pkg._id,
      packageWeightKg,
      delivererId: toDelOid,
    });
  }

  pkg.set({
    shelfId: String(destShelf.shelfId),
    slotId: String(destSlotId),
    delivererId: toDelOid,
  } as any);
  await pkg.save();

  return {
    ok: true,
    from: { shelfId: pkg.shelfId, slotId: pkg.slotId },
    to: { shelfId: destShelf.shelfId, slotId: destSlotId },
  };
}
