export interface Container {
    _id: string;
    orderId: string;
    qrUrl: string;
}