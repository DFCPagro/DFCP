export interface Address {
  lnt: number;
  alt: number;
  address: string;
  logisticCenterId?: string;
}
